<?php

use boctulus\LongCookies\core\libs\Autoloader;

require_once __DIR__ . '/../libs/Autoloader.php';

new Autoloader();