<?php

if (!function_exists('dd')){
	function dd($val){
		print_r($val);
	}
}