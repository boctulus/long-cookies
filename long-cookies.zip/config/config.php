<?php


return [
    
    'namespace'         => "boctulus\LongCookies", 
    'use_composer'      => false, // 

    'front_controller' => false,
    'router'           => false
];

