<?php

use boctulus\LongCookies\libs\Main;


new Main();